# Task 1: Terra Goods (Simple E-commerce Store)

A small store with product listings, search and category filter, a shopping cart, user accounts and order history.

## Features
- Product catalogue seeded in SQLite (8 sample products, prices in ₹)
- Client-side search and category filter
- Cart that persists in the browser, with quantity controls
- Register and log in with hashed passwords and JWT
- Checkout creates an order; the **server recalculates totals from database prices**, so the client cannot change what it pays
- "My orders" history

## API
| Method | Route | Auth | Purpose |
|--------|-------|------|---------|
| POST | `/api/register`, `/api/login` | no | Create account / log in |
| GET | `/api/products` | no | List products |
| POST | `/api/orders` | yes | Place order `{items:[{id,qty}]}` |
| GET | `/api/orders` | yes | Order history |

## Run
```bash
npm install
npm start   # http://localhost:3001
```

## Database
`users`, `products`, `orders`, `order_items`.
