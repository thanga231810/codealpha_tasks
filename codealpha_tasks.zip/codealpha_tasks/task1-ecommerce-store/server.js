const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const PORT = process.env.PORT || 3001;
const db = new Database(path.join(__dirname, 'data.db'));
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT, price INTEGER NOT NULL, emoji TEXT, category TEXT);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), total INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id), product_id INTEGER NOT NULL REFERENCES products(id), quantity INTEGER NOT NULL, price INTEGER NOT NULL);
`);

if (db.prepare('SELECT COUNT(*) c FROM products').get().c === 0) {
  const ins = db.prepare('INSERT INTO products(name,description,price,emoji,category) VALUES(?,?,?,?,?)');
  [
    ['Filter coffee powder, 500 g', 'Medium roast with chicory, ground for a decoction filter.', 320, '☕', 'Pantry'],
    ['Cold-pressed groundnut oil, 1 L', 'Pressed in small batches, good for everyday cooking.', 360, '🥜', 'Pantry'],
    ['Jaggery, 1 kg', 'Unrefined cane jaggery, sold as a block.', 140, '🍯', 'Pantry'],
    ['Cotton kitchen towel set', 'Three absorbent towels in woven check.', 249, '🧺', 'Home'],
    ['Brass tumbler', 'Hand-finished tumbler, 300 ml.', 540, '🥛', 'Home'],
    ['Terracotta planter', 'Unglazed planter with a drainage hole.', 280, '🪴', 'Home'],
    ['Handloom cotton scarf', 'Light scarf in undyed cotton.', 690, '🧣', 'Wear'],
    ['Ruled notebook, A5', '160 pages of 90 gsm paper, stitched binding.', 120, '📓', 'Stationery'],
  ].forEach(p => ins.run(...p));
}

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const auth = (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET); next(); }
  catch { res.status(401).json({ error: 'Please log in first.' }); }
};
const wrap = fn => (req, res) => {
  try { fn(req, res); } catch (e) { console.error(e); res.status(500).json({ error: 'Something went wrong on the server.' }); }
};
const session = u => ({ token: jwt.sign({ id: u.id, username: u.username }, SECRET, { expiresIn: '7d' }), username: u.username, id: u.id });

app.post('/api/register', wrap((req, res) => {
  const username = String((req.body || {}).username || '').trim();
  const password = String((req.body || {}).password || '');
  if (!username || password.length < 6) return res.status(400).json({ error: 'Enter a username and a password of at least 6 characters.' });
  try {
    const id = db.prepare('INSERT INTO users(username,password_hash) VALUES(?,?)').run(username, bcrypt.hashSync(password, 10)).lastInsertRowid;
    res.json(session({ id, username }));
  } catch { res.status(409).json({ error: 'That username is already taken.' }); }
}));

app.post('/api/login', wrap((req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(String(username || '').trim());
  if (!u || !bcrypt.compareSync(String(password || ''), u.password_hash)) return res.status(401).json({ error: 'Wrong username or password.' });
  res.json(session(u));
}));

app.get('/api/products', wrap((req, res) => res.json(db.prepare('SELECT * FROM products ORDER BY id').all())));

app.post('/api/orders', auth, wrap((req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items : [];
  if (!items.length) return res.status(400).json({ error: 'Your cart is empty.' });
  const getProduct = db.prepare('SELECT id, price FROM products WHERE id=?');
  const place = db.transaction(() => {
    let total = 0; const rows = [];
    for (const it of items) {
      const p = getProduct.get(it.id); const q = Math.floor(Number(it.qty));
      if (!p || !(q > 0) || q > 99) throw new Error('invalid item');
      total += p.price * q; rows.push([p.id, q, p.price]);
    }
    const id = db.prepare('INSERT INTO orders(user_id,total) VALUES(?,?)').run(req.user.id, total).lastInsertRowid;
    const ins = db.prepare('INSERT INTO order_items(order_id,product_id,quantity,price) VALUES(?,?,?,?)');
    rows.forEach(r => ins.run(id, ...r));
    return { id, total };
  });
  try { res.json(place()); } catch { res.status(400).json({ error: 'Some items in your cart are no longer available.' }); }
}));

app.get('/api/orders', auth, wrap((req, res) => {
  const orders = db.prepare('SELECT id, total, created_at FROM orders WHERE user_id=? ORDER BY id DESC').all(req.user.id);
  const items = db.prepare('SELECT oi.quantity, oi.price, p.name FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=?');
  res.json(orders.map(o => ({ ...o, items: items.all(o.id) })));
}));

app.listen(PORT, () => console.log(`Terra Goods running at http://localhost:${PORT}`));
