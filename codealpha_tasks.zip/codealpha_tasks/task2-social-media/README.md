# Task 2: Kuruvi (Social Media Platform)

A short-post social network with profiles, following, likes and comments.

## Features
- Register and log in (JWT)
- Create posts up to 280 characters; delete your own posts
- Like and unlike, comment on posts
- Follow and unfollow users; "Following" tab shows your feed
- Click a username to see that user's profile and posts

## API
| Method | Route | Purpose |
|--------|-------|---------|
| POST | `/api/register`, `/api/login` | Auth |
| GET | `/api/posts?scope=all\|following&user=name` | Feed or profile posts |
| POST / DELETE | `/api/posts`, `/api/posts/:id` | Create / delete post |
| POST | `/api/posts/:id/like` | Toggle like |
| GET / POST | `/api/posts/:id/comments` | List / add comments |
| POST | `/api/users/:id/follow` | Toggle follow |
| GET | `/api/users/:username` | Profile counts |

## Run
```bash
npm install
npm start   # http://localhost:3002
```

## Database
`users`, `posts`, `likes`, `comments`, `follows`.
