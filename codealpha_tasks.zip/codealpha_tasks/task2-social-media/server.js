const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const PORT = process.env.PORT || 3002;
const db = new Database(path.join(__dirname, 'data.db'));
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS likes(user_id INTEGER NOT NULL REFERENCES users(id), post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE, PRIMARY KEY(user_id, post_id));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY, post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE, user_id INTEGER NOT NULL REFERENCES users(id), body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS follows(follower_id INTEGER NOT NULL REFERENCES users(id), following_id INTEGER NOT NULL REFERENCES users(id), PRIMARY KEY(follower_id, following_id));
`);

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const auth = (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET); next(); }
  catch { res.status(401).json({ error: 'Please log in first.' }); }
};
const wrap = fn => (req, res) => {
  try { fn(req, res); } catch (e) { console.error(e); res.status(500).json({ error: 'Something went wrong on the server.' }); }
};
const session = u => ({ token: jwt.sign({ id: u.id, username: u.username }, SECRET, { expiresIn: '7d' }), username: u.username, id: u.id });

app.post('/api/register', wrap((req, res) => {
  const username = String((req.body || {}).username || '').trim();
  const password = String((req.body || {}).password || '');
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: 'Username must be 3-20 letters, numbers or underscores.' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  try {
    const id = db.prepare('INSERT INTO users(username,password_hash) VALUES(?,?)').run(username, bcrypt.hashSync(password, 10)).lastInsertRowid;
    res.json(session({ id, username }));
  } catch { res.status(409).json({ error: 'That username is already taken.' }); }
}));

app.post('/api/login', wrap((req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(String(username || '').trim());
  if (!u || !bcrypt.compareSync(String(password || ''), u.password_hash)) return res.status(401).json({ error: 'Wrong username or password.' });
  res.json(session(u));
}));

// Feed: scope=all | following, optional user=<username> for a profile view
app.get('/api/posts', auth, wrap((req, res) => {
  const me = req.user.id, where = [], params = [me, me];
  if (req.query.scope === 'following') { where.push('(p.user_id IN (SELECT following_id FROM follows WHERE follower_id=?) OR p.user_id=?)'); params.push(me, me); }
  if (req.query.user) { where.push('u.username=?'); params.push(String(req.query.user)); }
  const sql = `SELECT p.id, p.body, p.created_at, u.id AS user_id, u.username,
    (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) AS likes,
    EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=?) AS liked,
    EXISTS(SELECT 1 FROM follows f WHERE f.follower_id=? AND f.following_id=u.id) AS following,
    (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comment_count
    FROM posts p JOIN users u ON u.id=p.user_id ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY p.id DESC LIMIT 50`;
  res.json(db.prepare(sql).all(...params));
}));

app.post('/api/posts', auth, wrap((req, res) => {
  const body = String(req.body.body || '').trim();
  if (!body || body.length > 280) return res.status(400).json({ error: 'A post needs 1 to 280 characters.' });
  const id = db.prepare('INSERT INTO posts(user_id,body) VALUES(?,?)').run(req.user.id, body).lastInsertRowid;
  res.json({ id });
}));

app.delete('/api/posts/:id', auth, wrap((req, res) => {
  const r = db.prepare('DELETE FROM posts WHERE id=? AND user_id=?').run(req.params.id, req.user.id);
  if (!r.changes) return res.status(404).json({ error: 'Post not found, or it is not yours.' });
  res.json({ ok: true });
}));

app.post('/api/posts/:id/like', auth, wrap((req, res) => {
  const id = +req.params.id;
  if (!db.prepare('SELECT 1 FROM posts WHERE id=?').get(id)) return res.status(404).json({ error: 'Post not found.' });
  const del = db.prepare('DELETE FROM likes WHERE user_id=? AND post_id=?').run(req.user.id, id);
  if (!del.changes) db.prepare('INSERT INTO likes(user_id,post_id) VALUES(?,?)').run(req.user.id, id);
  res.json({ liked: !del.changes, likes: db.prepare('SELECT COUNT(*) c FROM likes WHERE post_id=?').get(id).c });
}));

app.get('/api/posts/:id/comments', auth, wrap((req, res) => {
  res.json(db.prepare('SELECT c.id, c.body, c.created_at, u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id').all(req.params.id));
}));

app.post('/api/posts/:id/comments', auth, wrap((req, res) => {
  const body = String(req.body.body || '').trim();
  if (!body || body.length > 280) return res.status(400).json({ error: 'A comment needs 1 to 280 characters.' });
  if (!db.prepare('SELECT 1 FROM posts WHERE id=?').get(req.params.id)) return res.status(404).json({ error: 'Post not found.' });
  db.prepare('INSERT INTO comments(post_id,user_id,body) VALUES(?,?,?)').run(req.params.id, req.user.id, body);
  res.json({ ok: true });
}));

app.post('/api/users/:id/follow', auth, wrap((req, res) => {
  const target = +req.params.id;
  if (target === req.user.id) return res.status(400).json({ error: 'You cannot follow yourself.' });
  if (!db.prepare('SELECT 1 FROM users WHERE id=?').get(target)) return res.status(404).json({ error: 'User not found.' });
  const del = db.prepare('DELETE FROM follows WHERE follower_id=? AND following_id=?').run(req.user.id, target);
  if (!del.changes) db.prepare('INSERT INTO follows(follower_id,following_id) VALUES(?,?)').run(req.user.id, target);
  res.json({ following: !del.changes });
}));

app.get('/api/users/:username', auth, wrap((req, res) => {
  const u = db.prepare('SELECT id, username FROM users WHERE username=?').get(req.params.username);
  if (!u) return res.status(404).json({ error: 'User not found.' });
  const c = q => db.prepare(q).get(u.id).c;
  res.json({ ...u,
    followers: c('SELECT COUNT(*) c FROM follows WHERE following_id=?'),
    following: c('SELECT COUNT(*) c FROM follows WHERE follower_id=?'),
    posts: c('SELECT COUNT(*) c FROM posts WHERE user_id=?') });
}));

app.listen(PORT, () => console.log(`Kuruvi running at http://localhost:${PORT}`));
