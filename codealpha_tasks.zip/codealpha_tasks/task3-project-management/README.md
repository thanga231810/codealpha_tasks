# Task 3: Padi Board (Project Management Tool)

A Kanban-style tool with auth, projects, task cards, comments and notifications.

## Features
- Register and log in (JWT)
- Create projects; the owner adds members by username
- Task board with To do, In progress and Done columns; move tasks with drag and drop or the arrow buttons
- Assign tasks to project members
- Comments on every task
- **Bonus: notifications and live updates.** You are notified when you are added to a project, assigned a task, or someone comments on your task. The client polls every 4 seconds so changes from other users appear without a refresh.
- Access control: only project members can view or change a project's data

## Upgrading polling to WebSockets
The polling in `public/index.html` (`setInterval`) can be replaced with the `ws` package: broadcast an event from the server after each write and call `loadBoard(true)` and `pollNotifs()` when it arrives.

## API
| Method | Route | Purpose |
|--------|-------|---------|
| POST | `/api/register`, `/api/login` | Auth |
| GET / POST | `/api/projects` | List / create projects |
| GET | `/api/projects/:id` | Project, members and tasks |
| POST | `/api/projects/:id/members` | Add member (owner only) |
| POST | `/api/projects/:id/tasks` | Create task |
| PATCH / DELETE | `/api/tasks/:id` | Update status, title, assignee / delete |
| GET / POST | `/api/tasks/:id/comments` | List / add comments |
| GET | `/api/notifications` | Recent notifications and unread count |
| POST | `/api/notifications/read` | Mark all as read |

## Run
```bash
npm install
npm start   # http://localhost:3003
```

## Database
`users`, `projects`, `members`, `tasks`, `comments`, `notifications`.
