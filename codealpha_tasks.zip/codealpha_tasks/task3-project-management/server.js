const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const PORT = process.env.PORT || 3003;
const STATUSES = ['todo', 'doing', 'done'];
const db = new Database(path.join(__dirname, 'data.db'));
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT NOT NULL, owner_id INTEGER NOT NULL REFERENCES users(id));
CREATE TABLE IF NOT EXISTS members(project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE, user_id INTEGER NOT NULL REFERENCES users(id), PRIMARY KEY(project_id, user_id));
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE, title TEXT NOT NULL, description TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'todo', assignee_id INTEGER REFERENCES users(id), created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY, task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE, user_id INTEGER NOT NULL REFERENCES users(id), body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), message TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const auth = (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET); next(); }
  catch { res.status(401).json({ error: 'Please log in first.' }); }
};
const wrap = fn => (req, res) => {
  try { fn(req, res); } catch (e) { console.error(e); res.status(500).json({ error: 'Something went wrong on the server.' }); }
};
const session = u => ({ token: jwt.sign({ id: u.id, username: u.username }, SECRET, { expiresIn: '7d' }), username: u.username, id: u.id });
const isMember = (pid, uid) => !!db.prepare('SELECT 1 FROM members WHERE project_id=? AND user_id=?').get(pid, uid);
const notify = (uid, message) => db.prepare('INSERT INTO notifications(user_id,message) VALUES(?,?)').run(uid, message);
const NOT_MEMBER = { error: 'You are not a member of this project.' };

app.post('/api/register', wrap((req, res) => {
  const username = String((req.body || {}).username || '').trim();
  const password = String((req.body || {}).password || '');
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: 'Username must be 3-20 letters, numbers or underscores.' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  try {
    const id = db.prepare('INSERT INTO users(username,password_hash) VALUES(?,?)').run(username, bcrypt.hashSync(password, 10)).lastInsertRowid;
    res.json(session({ id, username }));
  } catch { res.status(409).json({ error: 'That username is already taken.' }); }
}));

app.post('/api/login', wrap((req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(String(username || '').trim());
  if (!u || !bcrypt.compareSync(String(password || ''), u.password_hash)) return res.status(401).json({ error: 'Wrong username or password.' });
  res.json(session(u));
}));

// Projects
app.get('/api/projects', auth, wrap((req, res) => {
  res.json(db.prepare('SELECT p.id, p.name, p.owner_id FROM projects p JOIN members m ON m.project_id=p.id WHERE m.user_id=? ORDER BY p.id DESC').all(req.user.id));
}));

app.post('/api/projects', auth, wrap((req, res) => {
  const name = String(req.body.name || '').trim();
  if (!name) return res.status(400).json({ error: 'Give the project a name.' });
  const id = db.transaction(() => {
    const pid = db.prepare('INSERT INTO projects(name,owner_id) VALUES(?,?)').run(name, req.user.id).lastInsertRowid;
    db.prepare('INSERT INTO members(project_id,user_id) VALUES(?,?)').run(pid, req.user.id);
    return pid;
  })();
  res.json({ id, name, owner_id: req.user.id });
}));

app.get('/api/projects/:id', auth, wrap((req, res) => {
  const pid = +req.params.id;
  if (!isMember(pid, req.user.id)) return res.status(403).json(NOT_MEMBER);
  res.json({
    project: db.prepare('SELECT id, name, owner_id FROM projects WHERE id=?').get(pid),
    members: db.prepare('SELECT u.id, u.username FROM members m JOIN users u ON u.id=m.user_id WHERE m.project_id=? ORDER BY u.username').all(pid),
    tasks: db.prepare(`SELECT t.id, t.title, t.description, t.status, t.assignee_id, t.created_by,
      (SELECT COUNT(*) FROM comments c WHERE c.task_id=t.id) AS comment_count FROM tasks t WHERE t.project_id=? ORDER BY t.id`).all(pid)
  });
}));

app.post('/api/projects/:id/members', auth, wrap((req, res) => {
  const pid = +req.params.id;
  const p = db.prepare('SELECT * FROM projects WHERE id=?').get(pid);
  if (!p || p.owner_id !== req.user.id) return res.status(403).json({ error: 'Only the project owner can add members.' });
  const u = db.prepare('SELECT id FROM users WHERE username=?').get(String(req.body.username || '').trim());
  if (!u) return res.status(404).json({ error: 'No user with that username.' });
  if (isMember(pid, u.id)) return res.status(409).json({ error: 'That user is already a member.' });
  db.prepare('INSERT INTO members(project_id,user_id) VALUES(?,?)').run(pid, u.id);
  notify(u.id, `${req.user.username} added you to "${p.name}"`);
  res.json({ ok: true });
}));

// Tasks
app.post('/api/projects/:id/tasks', auth, wrap((req, res) => {
  const pid = +req.params.id;
  if (!isMember(pid, req.user.id)) return res.status(403).json(NOT_MEMBER);
  const title = String(req.body.title || '').trim();
  if (!title) return res.status(400).json({ error: 'Give the task a title.' });
  const assignee = req.body.assignee_id ? +req.body.assignee_id : null;
  if (assignee && !isMember(pid, assignee)) return res.status(400).json({ error: 'The assignee must be a project member.' });
  const id = db.prepare('INSERT INTO tasks(project_id,title,description,assignee_id,created_by) VALUES(?,?,?,?,?)')
    .run(pid, title, String(req.body.description || '').trim(), assignee, req.user.id).lastInsertRowid;
  if (assignee && assignee !== req.user.id) notify(assignee, `${req.user.username} assigned you "${title}"`);
  res.json({ id });
}));

app.patch('/api/tasks/:id', auth, wrap((req, res) => {
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (!isMember(t.project_id, req.user.id)) return res.status(403).json(NOT_MEMBER);
  const b = req.body || {};
  const status = b.status ?? t.status;
  if (!STATUSES.includes(status)) return res.status(400).json({ error: 'Status must be todo, doing or done.' });
  const title = b.title !== undefined ? (String(b.title).trim() || t.title) : t.title;
  let assignee = t.assignee_id;
  if ('assignee_id' in b) {
    assignee = b.assignee_id ? +b.assignee_id : null;
    if (assignee && !isMember(t.project_id, assignee)) return res.status(400).json({ error: 'The assignee must be a project member.' });
  }
  db.prepare('UPDATE tasks SET title=?, status=?, assignee_id=? WHERE id=?').run(title, status, assignee, t.id);
  if (assignee && assignee !== t.assignee_id && assignee !== req.user.id) notify(assignee, `${req.user.username} assigned you "${title}"`);
  res.json({ ok: true });
}));

app.delete('/api/tasks/:id', auth, wrap((req, res) => {
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (!isMember(t.project_id, req.user.id)) return res.status(403).json(NOT_MEMBER);
  db.prepare('DELETE FROM tasks WHERE id=?').run(t.id);
  res.json({ ok: true });
}));

// Comments
app.get('/api/tasks/:id/comments', auth, wrap((req, res) => {
  const t = db.prepare('SELECT project_id FROM tasks WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (!isMember(t.project_id, req.user.id)) return res.status(403).json(NOT_MEMBER);
  res.json(db.prepare('SELECT c.id, c.body, c.created_at, u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.task_id=? ORDER BY c.id').all(req.params.id));
}));

app.post('/api/tasks/:id/comments', auth, wrap((req, res) => {
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (!isMember(t.project_id, req.user.id)) return res.status(403).json(NOT_MEMBER);
  const body = String(req.body.body || '').trim();
  if (!body) return res.status(400).json({ error: 'Write a comment first.' });
  db.prepare('INSERT INTO comments(task_id,user_id,body) VALUES(?,?,?)').run(t.id, req.user.id, body);
  new Set([t.created_by, t.assignee_id].filter(id => id && id !== req.user.id))
    .forEach(id => notify(id, `${req.user.username} commented on "${t.title}"`));
  res.json({ ok: true });
}));

// Notifications (the client polls these, so updates show up without a refresh)
app.get('/api/notifications', auth, wrap((req, res) => {
  res.json({
    unread: db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0').get(req.user.id).c,
    items: db.prepare('SELECT id, message, is_read, created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 20').all(req.user.id)
  });
}));
app.post('/api/notifications/read', auth, wrap((req, res) => {
  db.prepare('UPDATE notifications SET is_read=1 WHERE user_id=?').run(req.user.id);
  res.json({ ok: true });
}));

app.listen(PORT, () => console.log(`Padi Board running at http://localhost:${PORT}`));
