# CodeAlpha Full Stack Development Internship: Tasks

**Student:** Thangamani B  |  **Student ID:** CA/DF1/434207

Three full stack apps, each in its own folder with its own `package.json`, Express API, SQLite database and plain HTML/CSS/JavaScript frontend.

| Task | Folder | Port |
|------|--------|------|
| 1. Simple E-commerce Store | `task1-ecommerce-store` | 3001 |
| 2. Social Media Platform | `task2-social-media` | 3002 |
| 3. Project Management Tool | `task3-project-management` | 3003 |

## Run any task

Requires Node.js 18 or newer.

```bash
cd task1-ecommerce-store   # or task2-social-media / task3-project-management
npm install
npm start
```

Then open the URL printed in the terminal. The SQLite file (`data.db`) is created automatically on first run.

Set `JWT_SECRET` before deploying, for example `JWT_SECRET=some-long-random-string npm start`.

## Tech stack

- Frontend: HTML, CSS, vanilla JavaScript
- Backend: Node.js, Express
- Database: SQLite (better-sqlite3)
- Auth: bcryptjs password hashing, JWT sessions
