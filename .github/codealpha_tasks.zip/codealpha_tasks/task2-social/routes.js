const r=require('express').Router(),{store,id,authRoutes,auth}=require('../common'),db=store('social');
authRoutes(r);
const find=q=>db.get('posts').find(x=>x.id===q.params.id);
r.get('/posts',auth,(q,s)=>s.json(db.get('posts').slice().reverse()));
r.post('/posts',auth,(q,s)=>{
  if(!q.body.text)return s.status(400).json({error:'Write something'});
  const p={id:id(),user:q.user.id,name:q.user.name,text:q.body.text,likes:[],comments:[]};
  db.get('posts').push(p);db.save();s.json(p);
});
r.post('/posts/:id/like',auth,(q,s)=>{
  const p=find(q);if(!p)return s.sendStatus(404);
  const i=p.likes.indexOf(q.user.id);i<0?p.likes.push(q.user.id):p.likes.splice(i,1);db.save();s.json(p);
});
r.post('/posts/:id/comment',auth,(q,s)=>{
  const p=find(q);if(!p)return s.sendStatus(404);
  p.comments.push({name:q.user.name,text:q.body.text});db.save();s.json(p);
});
r.post('/follow/:uid',auth,(q,s)=>{
  const f=db.get('follows'),i=f.findIndex(x=>x.from===q.user.id&&x.to===q.params.uid);
  i<0?f.push({from:q.user.id,to:q.params.uid}):f.splice(i,1);db.save();s.json({ok:true});
});
r.get('/follows',auth,(q,s)=>s.json(db.get('follows').filter(x=>x.from===q.user.id).map(x=>x.to)));
module.exports=r;
