const r=require('express').Router(),{store,id,authRoutes,auth}=require('../common'),db=store('shop');
if(!db.get('products').length){
  [['Laptop',55000],['Phone',18000],['Headphones',2500],['Smart Watch',4000],['Keyboard',1200],['Backpack',1500]]
  .forEach(([name,price])=>db.get('products').push({id:id(),name,price}));db.save();
}
authRoutes(r);
r.get('/products',(q,s)=>s.json(db.get('products')));
r.post('/orders',auth,(q,s)=>{
  const items=(q.body.items||[]).map(i=>{const p=db.get('products').find(x=>x.id===i.id);return p&&{...p,qty:i.qty}}).filter(Boolean);
  if(!items.length)return s.status(400).json({error:'Cart is empty'});
  const o={id:id(),user:q.user.id,items,total:items.reduce((t,i)=>t+i.price*i.qty,0),date:new Date().toLocaleString()};
  db.get('orders').push(o);db.save();s.json(o);
});
r.get('/orders',auth,(q,s)=>s.json(db.get('orders').filter(o=>o.user===q.user.id).reverse()));
module.exports=r;
