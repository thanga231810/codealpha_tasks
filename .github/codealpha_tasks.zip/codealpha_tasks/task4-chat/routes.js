const r=require('express').Router(),{store,id,authRoutes,auth}=require('../common'),db=store('chat');
authRoutes(r);
r.get('/messages',auth,(q,s)=>s.json(db.get('messages').filter(m=>m.room===(q.query.room||'general')).slice(-100)));
r.post('/messages',auth,(q,s)=>{
  if(!q.body.text)return s.status(400).json({error:'Empty message'});
  const m={id:id(),room:q.body.room||'general',user:q.user.id,name:q.user.name,text:q.body.text,time:new Date().toLocaleTimeString()};
  db.get('messages').push(m);db.save();s.json(m);
});
module.exports=r;
