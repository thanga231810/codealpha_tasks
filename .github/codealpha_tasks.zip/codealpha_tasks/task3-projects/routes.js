const r=require('express').Router(),{store,id,authRoutes,auth}=require('../common'),db=store('projects');
authRoutes(r);
const mine=q=>db.get('projects').find(p=>p.id===q.params.id&&p.owner===q.user.id);
r.get('/projects',auth,(q,s)=>s.json(db.get('projects').filter(p=>p.owner===q.user.id)));
r.post('/projects',auth,(q,s)=>{
  if(!q.body.name)return s.status(400).json({error:'Project name required'});
  const p={id:id(),owner:q.user.id,name:q.body.name,tasks:[]};db.get('projects').push(p);db.save();s.json(p);
});
r.delete('/projects/:id',auth,(q,s)=>{const a=db.get('projects'),i=a.findIndex(p=>p.id===q.params.id&&p.owner===q.user.id);if(i>=0)a.splice(i,1);db.save();s.json({ok:true});});
r.post('/projects/:id/tasks',auth,(q,s)=>{
  const p=mine(q);if(!p)return s.sendStatus(404);
  p.tasks.push({id:id(),title:q.body.title,assignee:q.body.assignee||'',status:'todo'});db.save();s.json(p);
});
r.patch('/projects/:id/tasks/:tid',auth,(q,s)=>{
  const p=mine(q);if(!p)return s.sendStatus(404);
  const t=p.tasks.find(x=>x.id===q.params.tid);if(t)t.status=q.body.status;db.save();s.json(p);
});
r.delete('/projects/:id/tasks/:tid',auth,(q,s)=>{
  const p=mine(q);if(!p)return s.sendStatus(404);
  p.tasks=p.tasks.filter(x=>x.id!==q.params.tid);db.save();s.json(p);
});
module.exports=r;
